import { getDatabase } from "@netlify/database";
import crypto from "node:crypto";
import * as L from "./lib/logic.mjs";

export const config = { path: "/api/act" };
const SECRET = process.env.SESSION_SECRET, ADMIN = process.env.ADMIN_PASSWORD, BAD = "ID ya password galat hai.";
const J = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { "Content-Type": "application/json" } });
const sign = s => crypto.createHmac("sha256", SECRET).update(s).digest("base64url");
const mk = id => { const b = id + "." + (Date.now() + 30 * 864e5); return b + "." + sign(b); };
const chk = t => {
  const p = String(t || "").split("."); if (p.length !== 3) return null;
  const a = Buffer.from(sign(p[0] + "." + p[1])), c = Buffer.from(p[2]);
  return a.length === c.length && crypto.timingSafeEqual(a, c) && +p[1] > Date.now() ? p[0] : null;
};
const hash = pw => { const s = crypto.randomBytes(16).toString("hex"); return s + ":" + crypto.scryptSync(pw, s, 32).toString("hex"); };
const same = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && crypto.timingSafeEqual(x, y); };
const okPw = (pw, h) => { const [s, k] = String(h).split(":"); return !!k && same(crypto.scryptSync(pw, s, 32).toString("hex"), k); };

function view(db, s) {
  const empty = { settings: db.settings, members: {}, orders: [], payouts: [], funds: { royalty: 0, reward: 0 }, runs: [], adminFee: 0, tds: 0, seq: 0, ord: 0 };
  const strip = (u, own) => { const { pass, mobile, ...r } = u; return own ? { ...r, mobile } : r; };
  if (s === "ADMIN") { const ms = {}; for (const k in db.members) ms[k] = strip(db.members[k], true); return { ...db, members: ms }; }
  const u = db.members[s]; if (!u) return empty;
  const kids = {}; for (const y of Object.values(db.members)) for (const k of [y.parent, y.sponsor]) if (k) (kids[k] ||= []).push(y.id);
  const keep = new Set([s, u.parent, u.sponsor].filter(Boolean)), q = [s], seen = new Set([s]);
  while (q.length) for (const id of kids[q.shift()] || []) if (!seen.has(id)) { seen.add(id); keep.add(id); q.push(id); }
  const members = {}; for (const id of keep) members[id] = strip(db.members[id], id === s);
  return { ...empty, members, orders: db.orders.filter(o => o.member === s), payouts: db.payouts.filter(p => p.member === s) };
}

function act(a, p, sess, db) {
  if (a === "state") return {};
  if (a === "login") {
    const id = String(p.id || "").trim().toUpperCase();
    if (id === "ADMIN") return same(p.pass || "", ADMIN) ? { sess: "ADMIN", token: mk("ADMIN") } : { err: BAD };
    const u = db.members[id]; if (!u || u.company || !okPw(String(p.pass || ""), u.pass)) return { err: BAD };
    return { sess: id, token: mk(id) };
  }
  if (a === "signup") {
    const pass = String(p.pass || "");
    const r = L.signup({ name: String(p.name || ""), mobile: String(p.mobile || ""), pass, sponsor: String(p.sponsor || ""), leg: p.leg === "right" ? "right" : "left" });
    if (typeof r === "string") return { err: r };
    db.members[r.id].pass = hash(pass); return { sess: r.id, token: mk(r.id), newId: r.id };
  }
  if (!sess) return { err: "Pehle login karein." };
  if (sess !== "ADMIN") {
    if (a === "order") {
      const q = Math.max(1, Math.min(20, parseInt(p.qty) || 1)), t = x => String(x || "").trim();
      if (!/^\d{10}$/.test(t(p.mobile))) return { err: "Mobile number 10 digit ka hona chahiye." };
      if (!/^\d{6}$/.test(t(p.pin))) return { err: "Pincode 6 digit ka hona chahiye." };
      const o = L.placeOrder(sess, q, { name: t(p.name), mobile: t(p.mobile), addr: t(p.addr), pin: t(p.pin) });
      return { order: { id: o.id, bv: o.bv } };
    }
    if (a === "wd") { const r = L.requestWithdraw(sess, parseFloat(p.amt)); return typeof r === "string" ? { err: r } : {}; }
    return { err: "Not allowed." };
  }
  const s = db.settings;
  if (a === "run") return { run: L.runDaily() };
  if (a === "ship") { const o = db.orders.find(x => x.id === p.id); if (!o) return { err: "Order nahi mila." }; o.status = o.status === "Placed" ? "Shipped" : "Delivered"; return {}; }
  if (a === "approve" || a === "reject") {
    const x = db.payouts.find(y => y.id === p.id); if (!x || x.status !== "Pending") return { err: "Ye request pending nahi hai." };
    if (a === "approve") { x.status = "Paid"; db.adminFee += x.fee; db.tds += x.tds; }
    else { x.status = "Rejected"; const m = db.members[x.member]; m.wallet += x.amt; m.ledger.unshift({ t: Date.now(), type: "Refund", amt: x.amt, note: "Withdrawal reject: " + x.id }); }
    return {};
  }
  if (a === "give") { const m = db.members[p.id]; if (!m) return { err: "Member nahi mila." }; m.given[p.p] = true; return {}; }
  if (a === "settings") {
    const lv = String(p.levels || "").split(",").map(parseFloat).filter(x => !isNaN(x));
    if (lv.length !== 6) return { err: "Level income me 6 values chahiye." };
    for (const x of ["price", "delivery", "bv", "retail", "pair", "cap", "royaltyPer", "rewardPer", "adminPct", "tdsPct", "minWd"]) { const n = parseFloat(p[x]); if (!isNaN(n) && n >= 0) s[x] = n; }
    if (s.bv <= 0) s.bv = 700;
    s.levels = lv; s.siteUrl = String(p.siteUrl || "").trim(); return {};
  }
  return { err: "Unknown action." };
}

export default async (req) => {
  if (req.method !== "POST") return J({ err: "POST only" }, 405);
  if (!SECRET || !ADMIN) return J({ err: "Server setup adhura hai (SESSION_SECRET / ADMIN_PASSWORD)." }, 500);
  const { a, p = {} } = await req.json().catch(() => ({}));
  const sess = chk((req.headers.get("authorization") || "").replace("Bearer ", ""));
  const c = await getDatabase().pool.connect();
  try {
    await c.query("BEGIN");
    await c.query("INSERT INTO app_state(id,data) VALUES(1,$1) ON CONFLICT (id) DO NOTHING", [JSON.stringify(L.init())]);
    const { rows } = await c.query("SELECT data FROM app_state WHERE id=1 FOR UPDATE");
    const db = rows[0].data; L.use(db);
    const out = act(a, p, sess, db);
    if (out.err) { await c.query("ROLLBACK"); return J({ err: out.err }); }
    await c.query("UPDATE app_state SET data=$1 WHERE id=1", [JSON.stringify(db)]);
    await c.query("COMMIT");
    const s = out.sess ?? sess;
    return J({ ...out, sess: s, db: view(db, s) });
  } catch (e) {
    await c.query("ROLLBACK").catch(() => {}); console.error(e); return J({ err: "Server me dikkat aayi, thodi der baad koshish karein." }, 500);
  } finally { c.release(); }
};
