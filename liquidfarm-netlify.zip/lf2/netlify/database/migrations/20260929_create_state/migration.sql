CREATE TABLE app_state (
  id INT PRIMARY KEY,
  data JSONB NOT NULL
);
